from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
json_path = ROOT / "output" / "corpus-data.json"
js_path = ROOT / "output" / "data.js"

payload = json_path.read_text(encoding="utf-8")
js_path.write_text(f"window.CORPUS_PAYLOAD = {payload};\n", encoding="utf-8")

print(f"Wrote {js_path}")
